import problem18
"""
Author: Andrew Blair
Title: problem19.py
Description: (Provided By Rosalind)
Given: A string x, followed by the alphabet Σ from which x was constructed, followed by the states States, transition 
matrix Transition, and emission matrix Emission of an HMM (Σ, States, Transition, Emission).

Return: The probability Pr(x) that the HMM emits x.

Acknowledgements:
Vinay Poodari: Thank you for helping me work through the math behind this algorithm
Robert Shelansky: Thank you for helping me debug this algorithm
"""
def main():
    """
    Imports and uses the methods for constructing the data structures needed for the Viterbi class in problem18.py.
    Then runs the method viterbiAlgorithm in the Viterbi class in problem18.py. This returns two objects, the
    summed probability that the HMM emits x and the hidden path.
    :return: prints the final sum of the probability that the HMM emits x
    """
    # Data wrangle and construct data structures
    string, alphabet, states, transRow, emsRow = problem18.dataWrangler()
    emissionMatrix = problem18.emissionMatrixConstruction(emsRow, states, alphabet)
    transitionMatrix = problem18.transitionMatrixConstruction(transRow, states)
    alphabetDict = problem18.buildIndexDict(alphabet)
    statesDict = problem18.buildIndexDict(states)
    # Pass objects into the Viterbi class
    execute = problem18.Viterbi(string, alphabet, states, alphabetDict, statesDict, emissionMatrix, transitionMatrix)
    # Run the viterbiAlgorithm in problem18.py and obtain the last sums of the hidden states
    hiddenStateprobEMList, finalSum, probEMList = execute.viterbiAlgorithm()
    # Print the sum of the last values of the hidden state
    # print(sum(finalSum))
    x = sum(finalSum)
    print(x)

if __name__ == '__main__':
    main()